using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 5.0f; // control the speed
    private Rigidbody2D rb;
    public bool isDead = false;

    private AudioSource audioSource; // Reference to the AudioSource component
    public AudioClip flapSound; // Sound for flapping wings
    public AudioClip deathSound; // Sound for player death
    public AudioClip passObstacleSound; // Sound for passing an obstacle

    void Start()
    {
        // Get Rigidbody2D Component of the Player
        rb = GetComponent<Rigidbody2D>();
        audioSource = GetComponent<AudioSource>(); // Get the AudioSource component
    }

    // Update is called once per frame
    void Update()
    {
        // GetMouseButtonDown(0) --> left side mouse button pressed down
        if (Input.GetMouseButtonDown(0) && !isDead)
        {
            rb.velocity = Vector2.up * speed;
            PlayFlapSound(); // Play the flap sound
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (!isDead)
        {
            isDead = true;
            PlayDeathSound(); // Call the function to play the death sound
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Obstacle")) // Assuming obstacles are tagged as "Obstacle"
        {
            PlayPassObstacleSound(); // Play the sound for passing an obstacle
        }
    }

    private void PlayFlapSound()
    {
        if (audioSource != null && flapSound != null)
        {
            audioSource.PlayOneShot(flapSound); // Play the flap sound
        }
    }

    private void PlayDeathSound()
    {
        if (audioSource != null && deathSound != null)
        {
            audioSource.PlayOneShot(deathSound); // Play the death sound
        }
    }

    private void PlayPassObstacleSound()
    {
        if (audioSource != null && passObstacleSound != null)
        {
            audioSource.PlayOneShot(passObstacleSound); // Play the pass obstacle sound
        }
    }
}
